USE WishList;

INSERT INTO Usuario(Nome, Senha, Email)
VALUES				('Jadilson','1234', 'jadilson@gmail.com'),
					('Jonny','4321', 'jonny@gmail.com');
		

INSERT INTO Desejos(DescricaoDesejo, DesejoUsuario)
VALUES				('Ser Rico', 1),
					('Aprender a codar', 2);
					
		