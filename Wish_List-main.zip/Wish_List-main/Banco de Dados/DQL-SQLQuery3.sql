USE WishList;

SELECT * FROM Desejos;
SELECT * FROM Usuario;